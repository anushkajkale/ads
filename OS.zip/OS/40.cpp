#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

struct Process {
    int id;
    int arrivalTime;
    int burstTime;
    int remainingTime;
    int waitingTime;
    int turnAroundTime;
};

// Function prototypes
void sjf(vector<Process>& processes);
void srtf(vector<Process>& processes);
void calculateWaitingTimeSJF(vector<Process>& processes);
void calculateTurnAroundTimeSJF(vector<Process>& processes);
void calculateSRTF(vector<Process>& processes);
void printProcessDetails(vector<Process>& processes);
bool compareBurstTime(Process a, Process b);

int main() {
    vector<Process> processes = {{1, 0, 6, 6, 0, 0}, {2, 1, 8, 8, 0, 0}, {3, 2, 7, 7, 0, 0}, {4, 3, 3, 3, 0, 0}};

    // Uncomment the following line to run SJF
    // sjf(processes);

    // Uncomment the following line to run SRTF
     srtf(processes);

    return 0;
}

void sjf(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), compareBurstTime);
    calculateWaitingTimeSJF(processes);
    calculateTurnAroundTimeSJF(processes);
    printProcessDetails(processes);
}

void srtf(vector<Process>& processes) {
    calculateSRTF(processes);
    printProcessDetails(processes);
}

bool compareBurstTime(Process a, Process b) {
    return a.burstTime < b.burstTime;
}

void calculateWaitingTimeSJF(vector<Process>& processes) {
    processes[0].waitingTime = 0;
    for (size_t i = 1; i < processes.size(); ++i) {
        processes[i].waitingTime = processes[i - 1].waitingTime + processes[i - 1].burstTime;
    }
}

void calculateTurnAroundTimeSJF(vector<Process>& processes) {
    for (size_t i = 0; i < processes.size(); ++i) {
        processes[i].turnAroundTime = processes[i].waitingTime + processes[i].burstTime;
    }
}

void calculateSRTF(vector<Process>& processes) {
    int n = processes.size();
    int currentTime = 0;
    int completed = 0;
    int minRemainingTime = INT_MAX;
    int shortest = 0;
    bool found = false;

    while (completed != n) {
        for (int i = 0; i < n; ++i) {
            if (processes[i].arrivalTime <= currentTime && processes[i].remainingTime < minRemainingTime && processes[i].remainingTime > 0) {
                minRemainingTime = processes[i].remainingTime;
                shortest = i;
                found = true;
            }
        }

        if (!found) {
            ++currentTime;
            continue;
        }

        --processes[shortest].remainingTime;
        minRemainingTime = processes[shortest].remainingTime;
        if (minRemainingTime == 0) {
            minRemainingTime = INT_MAX;
        }

        if (processes[shortest].remainingTime == 0) {
            ++completed;
            found = false;
            processes[shortest].waitingTime = currentTime + 1 - processes[shortest].burstTime - processes[shortest].arrivalTime;
            if (processes[shortest].waitingTime < 0) {
                processes[shortest].waitingTime = 0;
            }
        }
        ++currentTime;
    }

    for (int i = 0; i < n; ++i) {
        processes[i].turnAroundTime = processes[i].burstTime + processes[i].waitingTime;
    }
}

void printProcessDetails(vector<Process>& processes) {
    cout << "Process ID\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n";
    for (const auto& process : processes) {
        cout << process.id << "\t\t" << process.arrivalTime << "\t\t" << process.burstTime << "\t\t" << process.waitingTime << "\t\t" << process.turnAroundTime << "\n";
    }
}
