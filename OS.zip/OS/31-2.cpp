#include <iostream>
#include <vector>
#include <limits.h>
using namespace std;

void bestFitMemoryPlacement(vector<int> blockSize, const vector<int>& processSize) {
    int n = blockSize.size();
    int m = processSize.size();
    vector<int> allocation(m, -1);

    for (int i = 0; i < m; i++) {
        int bestIndex = -1;
        for (int j = 0; j < n; j++) {
            if (blockSize[j] >= processSize[i]) {
                if (bestIndex == -1 || blockSize[j] < blockSize[bestIndex]) {
                    bestIndex = j;
                }
            }
        }

        if (bestIndex != -1) {
            allocation[i] = bestIndex;
            blockSize[bestIndex] -= processSize[i];
        }
    }

    cout << "Process No.\tProcess Size\tBlock no.\n";
    for (int i = 0; i < m; i++) {
        cout << " " << i + 1 << "\t\t" << processSize[i] << "\t\t";
        if (allocation[i] != -1)
            cout << allocation[i] + 1;
        else
            cout << "Not Allocated";
        cout << endl;
    }
}

int main() {
    vector<int> blockSize = {100, 500, 200, 300, 600};
    vector<int> processSize = {212, 417, 112, 426};

    bestFitMemoryPlacement(blockSize, processSize);

    return 0;
}
