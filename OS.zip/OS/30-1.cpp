#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Process {
    int pid;      // Process ID
    int burstTime; // Burst Time
    int remainingTime; // Remaining Time
};

void roundRobinScheduling(vector<Process>& processes, int timeSlice) {
    queue<Process> q;
    int currentTime = 0;

    for (auto& process : processes) {
        q.push(process);
    }

    while (!q.empty()) {
        Process currentProcess = q.front();
        q.pop();

        if (currentProcess.remainingTime > timeSlice) {
            currentTime += timeSlice;
            currentProcess.remainingTime -= timeSlice;
            q.push(currentProcess);
        } else {
            currentTime += currentProcess.remainingTime;
            currentProcess.remainingTime = 0;
            cout << "Process " << currentProcess.pid << " finished at time " << currentTime << endl;
        }
    }
}

int main() {
    vector<Process> processes = {
        {1, 10, 10},
        {2, 5, 5},
        {3, 8, 8}
    };

    int timeSlice = 4;
    roundRobinScheduling(processes, timeSlice);

    return 0;
}
