#include <iostream>
#include <queue>
#include <unordered_set>

#include <vector>

#include <unordered_map>


using namespace std;

int pageFaultsFIFO(int pages[], int n, int capacity) {
    unordered_set<int> s;
    queue<int> indexes;
    int page_faults = 0;

    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
                indexes.push(pages[i]);
            }
        } else {
            if (s.find(pages[i]) == s.end()) {
                int val = indexes.front();
                indexes.pop();
                s.erase(val);
                s.insert(pages[i]);
                indexes.push(pages[i]);
                page_faults++;
            }
        }
    }

    return page_faults;
}

int pageFaultsOptimal(int pages[], int n, int capacity) {
    unordered_set<int> s;
    unordered_map<int, int> index;
    int page_faults = 0;

    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
            }
            index[pages[i]] = i;
        } else {
            if (s.find(pages[i]) == s.end()) {
                int farthest = i + 1, val = -1;
                for (auto it = s.begin(); it != s.end(); it++) {
                    if (index[*it] > farthest) {
                        farthest = index[*it];
                        val = *it;
                    }
                }
                if (val == -1) {
                    for (auto it = s.begin(); it != s.end(); it++) {
                        if (index[*it] < farthest) {
                            farthest = index[*it];
                            val = *it;
                        }
                    }
                }
                s.erase(val);
                s.insert(pages[i]);
                page_faults++;
            }
            index[pages[i]] = i;
        }
    }

    return page_faults;
}
int main() {
    int pages[] = {7, 1, 0, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int n = sizeof(pages) / sizeof(pages[0]);
    int capacity = 3;

    cout << "Total Page Faults (FIFO): " << pageFaultsFIFO(pages, n, capacity) << endl;
    cout << "Total Page Faults (Optimal): " << pageFaultsOptimal(pages, n, capacity) << endl;

    return 0;
}
