#include <iostream>
#include <vector>

using namespace std;

const int PROCESSES = 5;
const int RESOURCES = 3;

// Function to check if the system is in a safe state
bool isSafe(vector<vector<int>>& allocation, vector<vector<int>>& max, vector<int>& available) {
    vector<vector<int>> need(PROCESSES, vector<int>(RESOURCES));
    vector<bool> finish(PROCESSES, false);
    vector<int> safeSequence(PROCESSES);
    vector<int> work = available;

    // Calculate Need matrix
    for (int i = 0; i < PROCESSES; i++) {
        for (int j = 0; j < RESOURCES; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }

    int count = 0;
    while (count < PROCESSES) {
        bool found = false;
        for (int p = 0; p < PROCESSES; p++) {
            if (!finish[p]) {
                int j;
                for (j = 0; j < RESOURCES; j++) {
                    if (need[p][j] > work[j])
                        break;
                }
                if (j == RESOURCES) {
                    for (int k = 0; k < RESOURCES; k++) {
                        work[k] += allocation[p][k];
                    }
                    safeSequence[count++] = p;
                    finish[p] = true;
                    found = true;
                }
            }
        }
        if (!found) {
            cout << "System is not in a safe state\n";
            return false;
        }
    }
    cout << "System is in a safe state.\nSafe sequence is: ";
    for (int i = 0; i < PROCESSES; i++)
        cout << safeSequence[i] << " ";
    cout << endl;
    return true;
}

int main() {
    // Allocation Matrix
    vector<vector<int>> allocation = {
        {0, 1, 0},
        {2, 0, 0},
        {3, 0, 2},
        {2, 1, 1},
        {0, 0, 2}
    };

    // Max Matrix
    vector<vector<int>> max = {
        {7, 5, 3},
        {3, 2, 2},
        {9, 0, 2},
        {2, 2, 2},
        {4, 3, 3}
    };

    // Available resources
    vector<int> available = {3, 3, 2};

    isSafe(allocation, max, available);

    return 0;
}
