#include <iostream>
#include <vector>

using namespace std;

const int PROCESSES = 5;
const int RESOURCES = 3;

// Function to check for deadlock
bool isDeadlocked(vector<vector<int>>& allocation, vector<vector<int>>& request, vector<int>& available) {
    vector<bool> finish(PROCESSES, false);
    vector<int> work = available;

    bool progress = true;
    while (progress) {
        progress = false;
        for (int p = 0; p < PROCESSES; p++) {
            if (!finish[p]) {
                int j;
                for (j = 0; j < RESOURCES; j++) {
                    if (request[p][j] > work[j])
                        break;
                }
                if (j == RESOURCES) {
                    for (int k = 0; k < RESOURCES; k++) {
                        work[k] += allocation[p][k];
                    }
                    finish[p] = true;
                    progress = true;
                }
            }
        }
    }

    // Check for any unfinished processes
    for (int i = 0; i < PROCESSES; i++) {
        if (!finish[i]) {
            cout << "System is in deadlock.\n";
            cout << "Deadlocked processes: ";
            for (int j = 0; j < PROCESSES; j++) {
                if (!finish[j]) {
                    cout << "P" << j << " ";
                }
            }
            cout << endl;
            return true;
        }
    }

    cout << "System is not in deadlock.\n";
    return false;
}

int main() {
    // Allocation Matrix
    vector<vector<int>> allocation = {
        {0, 1, 0},
        {2, 0, 0},
        {3, 0, 3},
        {2, 1, 1},
        {0, 0, 2}
    };

    // Request Matrix
    vector<vector<int>> request = {
        {0, 0, 0},
        {2, 0, 2},
        {0, 0, 0},
        {1, 0, 0},
        {0, 0, 2}
    };

    // Available resources
    vector<int> available = {0, 0, 0};

    isDeadlocked(allocation, request, available);

    return 0;
}
