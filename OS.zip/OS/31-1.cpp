#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int fcfsDiskScheduling(const vector<int>& requests, int head) {
    int totalHeadMovements = 0;
    int currentPosition = head;

    for (int request : requests) {
        totalHeadMovements += abs(request - currentPosition);
        currentPosition = request;
    }

    return totalHeadMovements;
}

int main() {
    vector<int> requests = {98, 183, 37, 122, 14, 124, 65, 67};
    int head = 53;

    int totalHeadMovements = fcfsDiskScheduling(requests, head);
    cout << "Total head movements: " << totalHeadMovements << endl;

    return 0;
}
