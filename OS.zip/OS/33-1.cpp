#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int SCAN(vector<int> requests, int head, int disk_size) {
    sort(requests.begin(), requests.end());
    int total_head_movement = 0;
    int current_pos = head;
    
    vector<int> left, right;
    
    // Splitting requests into left and right of the head
    for (int i = 0; i < requests.size(); i++) {
        if (requests[i] < head)
            left.push_back(requests[i]);
        else
            right.push_back(requests[i]);
    }
    
    // Sort left in reverse order to service from highest to lowest
    sort(left.begin(), left.end(), greater<int>());
    
    // Move towards the end of the disk
    for (int i = 0; i < right.size(); i++) {
        total_head_movement += abs(current_pos - right[i]);
        current_pos = right[i];
    }
    
    // Reverse direction and move towards the beginning of the disk
    if (left.size() > 0) {
        total_head_movement += abs(current_pos - (disk_size - 1)); // Move to end first
        current_pos = disk_size - 1;
    }
    
    for (int i = 0; i < left.size(); i++) {
        total_head_movement += abs(current_pos - left[i]);
        current_pos = left[i];
    }
    
    return total_head_movement;
}

int main() {
    vector<int> requests = {98, 183, 37, 122, 14, 124, 65, 67};
    int head = 53;
    int disk_size = 200; // assuming disk size
    
    int total_head_movement = SCAN(requests, head, disk_size);
    cout << "Total head movement: " << total_head_movement << endl;
    
    return 0;
}
