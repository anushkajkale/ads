#include <iostream>
#include <vector>
#include <cmath>
#include <climits> // Include this header for INT_MAX
using namespace std;

int findClosestRequest(const vector<int>& requests, int head) {
    int minDistance = INT_MAX;
    int closestIndex = -1;

    for (int i = 0; i < requests.size(); i++) {
        int distance = abs(requests[i] - head);
        if (distance < minDistance) {
            minDistance = distance;
            closestIndex = i;
        }
    }

    return closestIndex;
}

int sstfDiskScheduling(vector<int> requests, int head) {
    int totalHeadMovements = 0;

    while (!requests.empty()) {
        int closestIndex = findClosestRequest(requests, head);
        totalHeadMovements += abs(requests[closestIndex] - head);
        head = requests[closestIndex];
        requests.erase(requests.begin() + closestIndex);
    }

    return totalHeadMovements;
}

int main() {
    vector<int> requests = {98, 183, 37, 122, 14, 124, 65, 67};
    int head = 53;

    int totalHeadMovements = sstfDiskScheduling(requests, head);
    cout << "Total head movements: " << totalHeadMovements << endl;

    return 0;
}
