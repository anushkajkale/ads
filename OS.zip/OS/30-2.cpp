#include <iostream>
#include <queue>
#include <unordered_set>
using namespace std;

int fifoPageReplacement(const vector<int>& pages, int frameCount) {
    unordered_set<int> frames;
    queue<int> pageQueue;
    int pageFaults = 0;

    for (int page : pages) {
        if (frames.find(page) == frames.end()) { // Page fault
            if (frames.size() == frameCount) {
                int oldPage = pageQueue.front();
                pageQueue.pop();
                frames.erase(oldPage);
            }
            frames.insert(page);
            pageQueue.push(page);
            pageFaults++;
        }
    }

    return pageFaults;
}

int main() {
    vector<int> pages = {7, 1, 0, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int frameCount = 3;
    int pageFaults = fifoPageReplacement(pages, frameCount);

    cout << "Total number of page faults: " << pageFaults << endl;

    return 0;
}
